﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LopushokApp
{
    public partial class ProductUserCntrl : UserControl
    {
        // закрытые поля пользовательского ЭУ
        public int ID;
        //private Color colFColor;
        private Color colBColor;
        private Image pictureImg;
        private string typeNameProductStr;
        private string articulStr;
        private string materialStr;
        private double costDbl;
        private int workshopNumber;
        private double minCost;

        public delegate void PUCHandler(string message, int id);
        public event PUCHandler Notify;

        public ProductUserCntrl()
        {
            InitializeComponent();
            // запоминаем цвет фона ЭУ при создании
            //BackColor1 = BackColor;
        }

        private void ProductUserCntrl_Load(object sender, EventArgs e)
        {            
           
        }
                
        public Image Picture
        {
            get { return pictureImg; }
            set
            {
                pictureImg = value;
                PictureBox.Image = pictureImg;
            }
        }
        public string TypeNameProduct
        {
            get{ return typeNameProductStr; }
            set
            {
                typeNameProductStr = value;
                TypeNameProductLbl.Text = typeNameProductStr;
            }
        }
        public string Articul
        {
            get{ return articulStr; }
            set
            {
                articulStr = value;
                ArticulLbl.Text = articulStr;
            }
        }
        public string Material
        {
            get { return materialStr; }
            set
            {
                materialStr = value;
                MaterialLbl.Text = materialStr;
            }
        }
        public double Cost
        {
            get{ return costDbl; }
            set
            {
                costDbl = value;
                CostLbl.Text = costDbl.ToString();
            }
        }
        public int WorkshopNumber
        {
            get { return workshopNumber; }
            set
            {
                workshopNumber = value;
                WorkshopLbl.Text = workshopNumber.ToString();
            }
        }
        public double MinCost
        {
            get { return minCost; }
            set
            {
                minCost = value;
                MinCostLbl.Text = minCost.ToString();
            }
        }
        private void ProductUserCntrl_Click(object sender, EventArgs e)
        {
            
        }

        private void ProductUserCntrl_MouseClick(object sender, MouseEventArgs e)
        {
            if(e.Button == MouseButtons.Right)
            {
                if (Form1.lstSelectedProduct.IndexOf(ID) != -1)
                { // если данный ПЭУ ВЫБРАН
                    BackColor = colBColor;
                    // удаляем из выборанных
                    Form1.lstSelectedProduct.Remove(ID);
                }
                else
                { // если данный ПЭУ НЕ ВЫБРАН
                    BackColor = Color.LightGray;
                    // добавляем к выбранным
                    Form1.lstSelectedProduct.Add(ID);
                }
                // Notify.Invoke("xxxxxx");
                if (Notify != null) Notify("Правая кнопка", ID);
            }
            if(e.Button == MouseButtons.Left)
            {
                if (Notify != null) Notify("Левая кнопка", ID);
            }
        }
    }
}
