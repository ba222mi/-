﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LopushokApp.ModelEF;

namespace LopushokApp
{
    public partial class Form1 : Form
    {
        // количество товаров на странице (форме)
        static int nProdList = 20;

        ////////////////////////////////////////
        // коллекция ID выбранных товаров
        static public List<int> lstSelectedProduct = new List<int>();

        public Form1()
        {
            InitializeComponent();
        }

        // коллекция показываемых товаров
        List<Product> lstProduct = new List<Product>();

        // коллекция пользов. элементов управления для показа
        List<ProductUserCntrl> lstControls = new List<ProductUserCntrl>();
        Button[] btnsList = new Button[5];
        private void Form1_Load(object sender, EventArgs e)
        {
            // устанавливаем тип сортировки
            SortCombo.SelectedIndex = 0;
            // загружаем список названий типов товаров
            List<string> lstTypes = Program.db.ProductType.Select(a => a.Title).ToList();
            lstTypes.Insert(0, "Все типы");
            // передаем данные фильтру
            FiltrCombo.DataSource = lstTypes;

            // заполняем коллекцию ПЭУ и размещаем ее в flowLayoutPanel1
            for (int i = 0; i < nProdList; i++)
            {
                // добавляем новый ПЭУ к коллекции lstControls
                lstControls.Add(new ProductUserCntrl());
                // подключаем обработчик события Notify
                lstControls[i].Notify += Notify;
                // добавляем новый ПЭУ к flowLayoutPanel 
                flowLayoutPanel1.Controls.Add(lstControls[i]);
            }
            {
                btnsList[0] = button1;
                btnsList[1] = button2;
                btnsList[2] = button3;
                btnsList[3] = button4;
                btnsList[4] = button5;
                SetPageBtn(1);
            }

            // подготавливаем данные для показа
            DataWork();
        }
        /////////////////////////////////////////////////
        // параметры показа продукции 
        string filtr = "Все типы"; // фильтр показа продукции;
        string sort = "Наименование"; // сортировки продукции
        string search = "";  // поиск по наименованию и описанию

        /////////////////////////////////////////////////////////// 
        // Данные для работы пользовательских элементов управления
        // после пересчета товаров показываем первую страницу
        int nProdNumber = 0;  // начальный номер товара на странице
        int nPageFirst = 1;   // номер первой кнопки на странице
        int nPageCurrent = 1; // номер текущей страницы
        int nPageAll = 0;     // всего страниц с товарами
        // номер нажатой (текущей, активной) кнопки
        int nActiveBtn = 1;      // Convert.ToInt32(button1.Text);     

        /////////////////////////////////////////////////
        //  Подготовка данных для показа 
        public void DataWork()
        {
            // вначале выбираем все товары
            lstProduct = Program.db.Product.ToList();

            /////////////////////////////////////////////            
            // фильтрация по типам товаров
            if (filtr != "Все типы")
            {
                // отбираем только по заданному производителю
                lstProduct = lstProduct.Where(p => (p.ProductType.Title == filtr)).ToList();
            }
            /////////////////////////////////////////////
            // поиск по заданной строке
            if (search != "")
            {   // отбираем товары с заданной строкой в названии
                search = search.ToUpper();
                // поиск с учетом регистра
                // ToUpper() для пустой строки не срабатывает
                lstProduct = lstProduct
                    .Where(p => (p.Title.ToUpper().Contains(search)) ||
                        (p.Description != null && // есть описание ?
                         p.Description.ToUpper().Contains(search)))
                    .ToList();
            }
            /////////////////////////////////////////////
            // сортировка по разным полям
            if (sort == "Без сортировки")
            {
                if (sort == "Наименование")
                {   // сортируем отобранные товары по наименованию
                    if (!DownCheck.Checked)
                        lstProduct = lstProduct.OrderBy(p => p.Title).ToList();
                    else
                        lstProduct = lstProduct.
                            OrderByDescending(p => p.Title).ToList();
                }
                if (sort == "Номер цеха")
                {   // сортируем отобранные товары по наименованию
                    if (!DownCheck.Checked)
                        lstProduct = lstProduct.OrderBy(p => p.ProductionWorkshopNumber).ToList();
                    else
                        lstProduct = lstProduct.
                            OrderByDescending(p => p.ProductionWorkshopNumber).ToList();
                }
                if (sort == "Мин.стоимость")
                {   // сортируем отобранные товары по наименованию
                    if (!DownCheck.Checked)
                        lstProduct = lstProduct.OrderBy(p => p.MinCostForAgent).ToList();
                    else
                        lstProduct = lstProduct.
                            OrderByDescending(p => p.MinCostForAgent).ToList();
                }
            }
            ////////////////////////////////////////////
            // вызов метода загрузки данных в ПЭУ  
            ShowCurrentPage();

            // что показываем на кнопках 
            nPageCurrent = 1;       // текущая страница
            nPageFirst = 1;  // первая кнопка = "1"
            // расчитываем общее кол-во страниц
            nPageAll = lstProduct.Count() / nProdList;           
            if (nPageAll * nProdList < lstProduct.Count())
                nPageAll++;
            // если страниц меньше, чем кнопок
            if(nPageAll <= 5)
            {
                if (nPageAll < 5)
                {
                    for (int i = nPageAll; i <= 5; i++)
                        btnsList[i - 1].Enabled = false;
                }
                RightBtn.Enabled = false;
            }
        }

        /////////////////////////////////////////////////
        // метод загрузки данных в ПЭУ  
        private void ShowCurrentPage()
        {
            int nProdMax = lstProduct.Count(); // максимальное коли-во товара

            // если данный товар выбран, то показываем кнопку "Изменить стоимость"
            if (lstSelectedProduct.Count > 0)
                CostChangeBtn.Visible = true;
            else
                CostChangeBtn.Visible = false;

            // расчитываем номер первого товара на странице
            nProdNumber = (nPageCurrent - 1) * nProdList;

            // счетчик номера товара на странице
            int i = nProdNumber;

            // цикл по UserControls, которые будут показываться на форме 
            // задаем свойства показываемых ПЭУ
            foreach (ProductUserCntrl puc in lstControls)
            {// каждому UserControls передаем данные (с помощью свойств)
             // проверяем, есть ли данные для очередного UserControls
                if (i < nProdMax)
                {
                    // сохраняем ID продукта
                    puc.ID = lstProduct[i].ID;

                    // проверяем - выбран этот ЭУ или нет?
                    if (lstSelectedProduct.IndexOf(puc.ID) != -1)
                    {// если данный ПЭУ ВЫБРАН, то фон меняем
                        puc.BackColor = Color.LightGray;
                    }
                    else
                    {// если не выбран, то начальный цвет
                        puc.BackColor = Color.White; // puc.BackColor1;
                    }
                    // задаем фото товара
                    if ((lstProduct[i].Image != "") && (lstProduct[i].Image != null))
                        // если фото у товара есть, добавляем его
                        puc.Picture = Image.FromFile(lstProduct[i].Image);
                    else  // если фото нет, то добавляем картинку по умолчанию
                        puc.Picture = Image.FromFile(@"products\picture.png");

                    // задаем строку "тип товара | название товара"
                    puc.TypeNameProduct = lstProduct[i].ProductType.Title + " | "
                        + lstProduct[i].Title;

                    // задаем артикул товара
                    puc.Articul = lstProduct[i].ArticleNumber;

                    // задаем список материалов и стоимость товара
                    // они составляются из списка товаров              
                    double cost = 0;
                    string mtr = "";
                    foreach (ProductMaterial prd_mtr in lstProduct[i].ProductMaterial)
                    {
                        if (prd_mtr.Count.HasValue)
                        {
                            if (mtr != "") mtr += ", ";
                            mtr += prd_mtr.Material.Title;
                            double n = prd_mtr.Count.Value;
                            cost += n * Convert.ToDouble(prd_mtr.Material.Cost);
                        }
                    }
                    puc.Material = mtr;
                    puc.Cost = cost;

                    // задаем цех производства товара, если задан 
                    if (lstProduct[i].ProductionWorkshopNumber.HasValue)
                    {
                        puc.WorkshopNumber = lstProduct[i].ProductionWorkshopNumber.Value;
                    }

                    //  задаем миним. стоимость для агента
                    puc.MinCost = Convert.ToDouble(lstProduct[i].MinCostForAgent);

                    // делаем данный ЭУ видимым 
                    puc.Visible = true;
                }
                else
                {   // если данных для ПЭУ нет
                    // делаем этот ПЭУ невидимым
                    puc.Visible = false;
                    // если данных уже нет, то кнопка враво не активная
                    RightBtn.Enabled = false;
                }
                i++; // счетчик номера товара увеличиваем
            }
            // если на последней странице показаны все товары
            // то кнопку тоже отключаем 
            if (i == nProdMax)
            {
                RightBtn.Enabled = false;
            }
            ////////////////////////////////////////////
            //  выводим надпись внизу формы 
            // 
            int max = nPageCurrent * nProdList;
            if (max > nProdMax) max = nProdMax;
            //  вывод сообщения о номерах показываемых товаров
            RangeLbl.Text = $"Товары с {nProdNumber + 1} по {max} (из всего {lstProduct.Count()})";
        }
        ////////////////////////////////////////////////////////////
        // переход к предыдущей странице товаров
        private void LeftBtn_Click(object sender, EventArgs e)
        {
            // вычисляем номер предыдущей страницы
            if (nActiveBtn > 1)
            {
                nPageCurrent--;
                nActiveBtn--;
                SetPageBtn(nPageCurrent);
            }
            else if (nActiveBtn == 1 && nPageFirst != 1)
            {
                ChangePageBtn(-1); // смещаем страницы влево на -1                
                nPageCurrent = Convert.ToInt32(button1.Text); // или nActiveBtn
                SetPageBtn(1);
            }
            // передаем данные для UserControl новой страницу с товарами
            ShowCurrentPage();
                
            if (nPageCurrent == 1 && nPageFirst == 1) 
                LeftBtn.Enabled = false;
            RightBtn.Enabled = false;
            if (nPageFirst + 4 < nPageAll)
                RightBtn.Enabled = true;
        }
        ////////////////////////////////////////////////////////////        
        // переход к следующей странице товаров
        private void RightBtn_Click(object sender, EventArgs e)
        {
            // вычисляем начальный номер товара на следующей странице
            if (nPageCurrent < nPageAll)
            {
                nPageCurrent++;
                if (nActiveBtn < 5)
                {
                    SetPageBtn(nPageCurrent);
                    nActiveBtn++;
                }
                else if (nActiveBtn == 5)
                {
                    ChangePageBtn(1);
                }
            }
            else
                RightBtn.Enabled = false;

            // передаем данные для UserControl новой страницу с товарами
            ShowCurrentPage();            
            
            // делаем кнопку "налево" активной
            LeftBtn.Enabled = true;                                       
        }

        ////////////////////////////////////////////////////////
        //  обработчики событий - сортировка, поиск, фильтрация
        private void SortCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            sort = SortCombo.Text;
            DataWork();
        }
        private void DownCheck_CheckedChanged(object sender, EventArgs e)
        {
            DataWork();
        }
        private void SearchTxt_TextChanged(object sender, EventArgs e)
        {
            search = SearchTxt.Text;
            DataWork();
        }

        private void FiltrCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            filtr = FiltrCombo.Text;
            DataWork();
        }

        private void Notify(string message, int id)
        {
            if (message == "Правая кнопка")
            {
                if (lstSelectedProduct.Count > 0)
                    CostChangeBtn.Visible = true;
                else
                    CostChangeBtn.Visible = false;
            }
            if (message == "Левая кнопка")
            {
                AddEditProductForm form = new AddEditProductForm();
                Product prd = lstProduct.Find(p => p.ID == id);
                form.prd = prd;

                DialogResult dr = form.ShowDialog();
                if (dr == DialogResult.OK)
                {
                    DataWork();
                    ShowCurrentPage();
                }
            }
        }

        private void CostChangeBtn_Click(object sender, EventArgs e)
        {
            CostChangeForm form = new CostChangeForm();
            DialogResult dr = form.ShowDialog();
            if (dr == DialogResult.OK)
            {
                DataWork();
                ShowCurrentPage();
            }
        }
        //  нажата кнопка "Добавить"
        private void AddProductBtn_Click(object sender, EventArgs e)
        {
            AddEditProductForm form = new AddEditProductForm();
            form.prd = null;
            DialogResult dr = form.ShowDialog();
            if (dr == DialogResult.OK)
            {
                DataWork();
                ShowCurrentPage();
            }
        }

        ////////////////////////////////////////////////////////
        // работа с кнопками перехода между страницами
        private void buttonN_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            // определяем номер показываемой страницы
            nPageCurrent = Convert.ToInt32(btn.Text);

            // устанавливаем активную кнопку (выделяется цветом и рамкой)
            int n = btn.Name.Length; // длина имени кнопки
            string str = btn.Name.Substring(n - 1); // в конце номер кнопки
            nActiveBtn = Convert.ToInt32(str);
            // показываем все кнопки выделением активной
            ShowActiveBtn();
            // загружаем данные в другую страницу            
            ShowCurrentPage();
        }
        void SetPageBtn(int nPage)
        {            
            for (int i=0; i<5; i++)
            {
                int ii = Convert.ToInt32(btnsList[i].Text);
                if (ii == nPage)
                    btnsList[i].BackColor = Color.LightBlue; 
                else
                    btnsList[i].BackColor = Color.White;                
            }
        }
        // показываем номер активной кнопки
        void ShowActiveBtn() // int nActiveBtn)
        {
            for (int i = 0; i < 5; i++)
            {
                int ii = Convert.ToInt32(btnsList[i].Text);
                if (ii == nActiveBtn)
                    btnsList[i].BackColor = Color.LightBlue;
                else
                    btnsList[i].BackColor = Color.White;
            }
        }
        void ChangePageBtn(int d)
        {
            if(nPageAll < 5)
            {
                for (int i = nPageAll; i < 5; i++)
                {
                    btnsList[i].Enabled = false;
                }
            }

            for (int i = 0; i < 5; i++)
            {
                int n = Convert.ToInt32(btnsList[i].Text) + d;
                if (n < 1) return;
                btnsList[i].Text = n.ToString();                
            }
            nPageFirst = Convert.ToInt32(btnsList[0].Text);
        }
    }
}
