﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LopushokApp.ModelEF;

namespace LopushokApp
{
    public partial class Form1 : Form
    {
        // количество товаров на странице (форме)
        static int nProdList = 20;

        ////////////////////////////////////////
        // коллекция ID выбранных товаров
        static public List<Product> lstSelectedProduct = new List<Product>();

        public Form1()
        {
            InitializeComponent();
        }

        // коллекция всех товаров
        List<Product> lstProduct = new List<Product>();

        // коллекция кнопок  для переходов между страницами
        Button[] btnsList = new Button[5];

        private void Form1_Load(object sender, EventArgs e)
        {
            // устанавливаем тип сортировки
            SortCombo.SelectedIndex = 0;
            // загружаем список названий типов товаров
            List<string> lstTypes = Program.db.ProductType.Select(a => a.Title).ToList();
            lstTypes.Insert(0, "Все типы");
            // передаем данные фильтру
            FiltrCombo.DataSource = lstTypes;

            { // создаем массив кнопок для удобства работы 
                btnsList[0] = button1;
                btnsList[1] = button2;
                btnsList[2] = button3;
                btnsList[3] = button4;
                btnsList[4] = button5;
                // показываем первую кнопку активной
                nActiveBtn = 1;                
                ShowActiveBtn();
            }

            // подготавливаем для показа и показываем данные 
            PodgotovkaData();
        }
        /////////////////////////////////////////////////
        // параметры показа продукции 
        string filtr = "Все типы"; // фильтр показа продукции;
        string sort = "Наименование"; // сортировки продукции
        string search = "";  // поиск по наименованию и описанию

        /////////////////////////////////////////////////////////// 
        // Данные для работы пользовательских элементов управления
        // после пересчета товаров показываем первую страницу
        int nPageFirstProduct = 0;  // начальный номер товара на странице
        int nPageFirst = 1;   // номер первой кнопки на странице
        int nPageCurrent = 1; // номер текущей страницы
        int nPageAll = 0;     // всего страниц с товарами
        // номер нажатой (текущей, активной) кнопки
        int nActiveBtn = 1;      // Convert.ToInt32(button1.Text);     

        /////////////////////////////////////////////////
        //  Подготовка данных для показа 
        public void PodgotovkaData()
        {
            // вначале выбираем все товары
            lstProduct = Program.db.Product.ToList();

            /////////////////////////////////////////////            
            // фильтрация по типам товаров
            if (filtr != "Все типы")
            {
                // отбираем только по заданному производителю
                lstProduct = lstProduct.Where(p => (p.ProductType.Title == filtr)).ToList();
            }
            /////////////////////////////////////////////
            // поиск по заданной строке
            if (search != "")
            {   // отбираем товары с заданной строкой в названии
                search = search.ToUpper();
                // поиск с учетом регистра
                // ToUpper() для пустой строки не срабатывает
                lstProduct = lstProduct
                    .Where(p => (p.Title.ToUpper().Contains(search)) ||
                        (p.Description != null && // есть описание ?
                         p.Description.ToUpper().Contains(search)))
                    .ToList();
            }
            /////////////////////////////////////////////
            // сортировка по разным полям
            if (sort != "Без сортировки")
            {   // сортируем отобранные товары по наименованию
                if (sort == "Наименование")
                {   // сортируем отобранные товары по наименованию
                    if (!DownCheck.Checked)
                        lstProduct = lstProduct.OrderBy(p => p.Title).ToList();
                    else
                        lstProduct = lstProduct.
                            OrderByDescending(p => p.Title).ToList();
                }
                if (sort == "Номер цеха")
                {   // сортируем отобранные товары по наименованию
                    if (!DownCheck.Checked)
                        lstProduct = lstProduct.OrderBy(p => p.ProductionWorkshopNumber).ToList();
                    else
                        lstProduct = lstProduct.
                            OrderByDescending(p => p.ProductionWorkshopNumber).ToList();
                }
                if (sort == "Мин.стоимость")
                {   // сортируем отобранные товары по наименованию
                    if (!DownCheck.Checked)
                        lstProduct = lstProduct.OrderBy(p => p.MinCostForAgent).ToList();
                    else
                        lstProduct = lstProduct.
                            OrderByDescending(p => p.MinCostForAgent).ToList();
                }
            }
            ////////////////////////////////////////////////////////
            // настройка ЭУ для перехода между страницами
            // расчитываем общее кол-во страниц
            nPageAll = lstProduct.Count() / nProdList;           
            if (nPageAll * nProdList < lstProduct.Count())
                nPageAll++;
            // задаем номер страницы и названия кнопок
            nPageCurrent = 1;       // текущая страница
            nPageFirst = 1;  // первая кнопка = "1"
            
            // если страниц меньше, чем кнопок
            if(nPageAll <= 5)
            {
                if (nPageAll > 0 && nPageAll < 5)
                {
                    for (int i = nPageAll; i <= 5; i++)
                        btnsList[i - 1].Enabled = false;
                }
                RightBtn.Enabled = false;
            }

            /////////////////////////////////////////////////
            // вызываем метод показа данных на странице
            // выполняется загрузка данных и показ
            ShowCurrentPage();
        }

        /////////////////////////////////////////////////
        // метод загрузки данных в DataGridView  
        private void ShowCurrentPage()
        {
            int nProdMax = lstProduct.Count(); // максимальное коли-во товара

            // расчитываем номер первого товара на странице            
            nPageFirstProduct = (nPageCurrent - 1) * nProdList; 
            // расчитываем номер последнего товара на странице            
            int nPageLastProduct = nPageFirstProduct + nProdList;

            // Используем две коллекции
            // 1 - исходные данные страницы (lstPageProduct)
            List<Product> lstPageProduct = new List<Product>();
            // 2 - рассчетные данные страницы (для показа)
            List<NewProduct> lstShowProduct = new List<NewProduct>();
            
            // создаем и заполняем коллекцию исходных даннs[ страницы
            for (int j = nPageFirstProduct; j < nPageLastProduct; j++)
            {
                if (j >= nProdMax) 
                    break;
                lstPageProduct.Add(lstProduct[j]);
            }
                       
            // создаем и заполняем коллекцию для показа
            // создаем объекты NewProduct
            foreach (Product prd in lstPageProduct)
            {
                NewProduct newPrd = new NewProduct();
                // сохраняем ID продукта
                newPrd.ID = prd.ID;
                newPrd.Title = prd.Title;
                // задаем название типа товара
                newPrd.ProductType = prd.ProductType.Title;
                // задаем артикул товара
                newPrd.ArticleNumber = prd.ArticleNumber;
                newPrd.Description = prd.Description;
                // задаем фото товара
                if ((prd.Image != "") && (prd.Image != null))
                    // если фото у товара есть, добавляем его
                    newPrd.picture = Image.FromFile(prd.Image);
                else  // если фото нет, то добавляем картинку по умолчанию
                    newPrd.picture = Image.FromFile(@"products\picture.png");
                // проверяем - выбран этот ЭУ или нет?
                //        if (lstSelectedProduct.IndexOf(puc.ID) != -1)
                //        {// если данный ПЭУ ВЫБРАН, то фон меняем
                //            puc.BackColor = Color.LightGray;
                //        }
                //        else
                //        {// если не выбран, то начальный цвет
                //            puc.BackColor = Color.White; // puc.BackColor1;
                //        }
                if (prd.ProductionPersonCount.HasValue)
                    newPrd.ProductionPersonCount = prd.ProductionPersonCount.Value;                
                // задаем цех производства товара, если задан
                if (prd.ProductionWorkshopNumber.HasValue)
                    newPrd.ProductionWorkshopNumber = prd.ProductionWorkshopNumber.Value;
                //  задаем миним. стоимость для агента
                newPrd.MinCostForAgent = Convert.ToDouble(prd.MinCostForAgent);  
                
                // задаем список материалов и стоимость товара
                // они составляются из списка товаров              
                double materialCost = 0;
                string mtr = "";
                foreach (ProductMaterial prd_mtr in prd.ProductMaterial)
                {
                    if (prd_mtr.Count.HasValue)
                    {
                        if (mtr != "") mtr += ", ";
                        mtr += prd_mtr.Material.Title;
                        double n = prd_mtr.Count.Value;
                        materialCost += n * Convert.ToDouble(prd_mtr.Material.Cost);
                    }
                }
                newPrd.Materials = mtr;
                newPrd.MaterialCost = materialCost;
                lstShowProduct.Add(newPrd);
            }

            // передаем товары данной страницы в ЭУ для показа
            // передаем промежуточному элементу
            newProductBindingSource.DataSource = lstShowProduct;

            //         
            // если на текущей странице показаны все товары
            // то кнопка "вправо" отключаем
            if ((nPageCurrent - 1) * nProdList + nProdList > nProdMax)
            {
                RightBtn.Enabled = false;
            }
            
            ////////////////////////////////////////////
            //  выводим надпись внизу формы 
            // 
            int listMax = nPageCurrent * nProdList;
            if (listMax > nProdMax) listMax = nProdMax;
            //  вывод сообщения о номерах показываемых товаров
            RangeLbl.Text = $"Товары с {nPageFirstProduct + 1} по {listMax} (из всего {lstProduct.Count()})";
        }
        ////////////////////////////////////////////////////////////
        // переход к предыдущей странице товаров
        private void LeftBtn_Click(object sender, EventArgs e)
        {
            // вычисляем номер предыдущей страницы
            if (nActiveBtn > 1)
            {
                nPageCurrent--;
                nActiveBtn--;
                ShowActiveBtn();
            }
            else if (nActiveBtn == 1 && nPageFirst != 1)
            {
                ChangePageBtn(-1); // смещаем страницы влево на -1                
                nPageCurrent = Convert.ToInt32(button1.Text); // или nActiveBtn
                nActiveBtn = 1;
                ShowActiveBtn();
            }
            // передаем данные для UserControl новой страницу с товарами
            ShowCurrentPage();
                
            if (nPageCurrent == 1 && nPageFirst == 1) 
                LeftBtn.Enabled = false;
            RightBtn.Enabled = false;
            if (nPageFirst + 4 < nPageAll)
                RightBtn.Enabled = true;
        }
        ////////////////////////////////////////////////////////////        
        // переход к следующей странице товаров
        private void RightBtn_Click(object sender, EventArgs e)
        {
            // вычисляем начальный номер товара на следующей странице
            if (nPageCurrent < nPageAll)
            {              
                // вычисляем начальный номер товара на следующей странице
                if (nPageCurrent < nPageAll)
                {
                    nPageCurrent++;
                    if (nActiveBtn < 5)
                    {
                        SetPageBtn(nPageCurrent);
                        nActiveBtn++;
                    }
                    else if (nActiveBtn == 5)
                    {
                        ChangePageBtn(1);
                    }
                }
                else
                    RightBtn.Enabled = false;

            }
            else
                RightBtn.Enabled = false;

            // передаем данные для UserControl новой страницу с товарами
            ShowCurrentPage();            
            
            // делаем кнопку "налево" активной
            LeftBtn.Enabled = true;                                       
        }

        ////////////////////////////////////////////////////////
        //  обработчики событий - сортировка, поиск, фильтрация
        private void SortCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            sort = SortCombo.Text;
            PodgotovkaData();
        }
        private void DownCheck_CheckedChanged(object sender, EventArgs e)
        {
            PodgotovkaData();
        }
        private void SearchTxt_TextChanged(object sender, EventArgs e)
        {
            search = SearchTxt.Text;
            PodgotovkaData();
        }

        private void FiltrCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            filtr = FiltrCombo.Text;
            PodgotovkaData();
        }

        private void CostChangeBtn_Click(object sender, EventArgs e)
        {
            // выбираем из DataGridView выбранные товары
            int selectedRowCount = newProductDataGridView.Rows
                .GetRowCount(DataGridViewElementStates.Selected);

            lstSelectedProduct.Clear();
            if (selectedRowCount > 0)
            {
                for (int i = 0; i < selectedRowCount; i++)
                {
                    int n = newProductDataGridView.SelectedRows[i].Index;
                    lstSelectedProduct.Add(lstProduct[n]);
                }
                //MessageBox.Show(selectedRowCount.ToString() + "Selected Rows");    
            }

            if (lstSelectedProduct.Count == 0) return;

            //  открываем форму для изменения стоимости выбранных товаров
            CostChangeForm form = new CostChangeForm();
            DialogResult dr = form.ShowDialog();
            if (dr == DialogResult.OK)
            {
                PodgotovkaData();
                ShowCurrentPage();
            }
        }
        ///////////////////////////////////////////////////
        //  нажата кнопка "Добавить"
        private void AddProductBtn_Click(object sender, EventArgs e)
        {
            AddEditProductForm form = new AddEditProductForm();
            form.prd = null;
            DialogResult dr = form.ShowDialog();
            if (dr == DialogResult.OK)
            {
                PodgotovkaData();
                ShowCurrentPage();
            }
        }
        ///////////////////////////////////////////////////
        //  нажата кнопка "Редактировать"
        private void EditProductBtn_Click(object sender, EventArgs e)
        {
            // находим текущий товар (NewProduct)
            NewProduct newPrd = (NewProduct)newProductBindingSource.Current;
            // ищем исходный товар
            Product prd = Program.db.Product.Find(newPrd.ID);
            AddEditProductForm form = new AddEditProductForm();
            form.prd = prd;
            DialogResult dr = form.ShowDialog();
            if (dr == DialogResult.OK)
            {
                PodgotovkaData();
                ShowCurrentPage();
            }
        }
        ///////////////////////////////////////////////////
        //  нажата кнопка "Удалить"
        private void DeleteProductBtn_Click(object sender, EventArgs e)
        {
            Product prd = (Product)productBindingSource.Current;
            DialogResult dr = MessageBox.Show("Вы действительно хотите удалить продукт - " + prd.Title,
               "Удаление продукции", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                // Проверяем - можно ли удалять эту продукцию
                // проверяем - есть ли данные о продажах товара?
                if (prd.ProductSale.Count > 0)
                {
                    MessageBox.Show("Данную продукцию удалить нельзя, т.к. есть данные о продажах!");
                    return;
                }
                // проверяем - есть данные о материалах?
                if (prd.ProductMaterial.Count > 0)
                {//  удаляем данные о материалах
                    //foreach (ProductMaterial prd_mtr in prd.ProductMaterial)
                    //{
                    //    Program.db.ProductMaterial.Remove(prd_mtr);
                    //}
                    Program.db.ProductMaterial.RemoveRange(prd.ProductMaterial);
                }
                // проверяем - есть данные о истории стоимости?
                if (prd.ProductCostHistory.Count > 0)
                {//  удаляем данные о истории стоимости
                    //foreach (ProductCostHistory prd_hist in prd.ProductCostHistory)
                    //{
                    //    Program.db.ProductCostHistory.Remove(prd_hist);
                    //}
                    Program.db.ProductCostHistory.RemoveRange(prd.ProductCostHistory);
                }

                // удаляем выбранный объект из коллекции
                Program.db.Product.Remove(prd);

                // сохраняем сделанные изменения в БД
                try  // обрабатываем исключения
                {
                    // сохраняем сделанные изменения в БД
                    Program.db.SaveChanges();
                    // завершаем работу формы
                    DialogResult = DialogResult.OK;
                }
                catch (Exception ex)  // если ошибка, то попадаем сюда
                {
                    // выводим сообщение SQL Server об ошибке
                    MessageBox.Show(ex.InnerException.InnerException.Message);
                }
            }
        }

        ////////////////////////////////////////////////////////
        // работа с кнопками перехода между страницами
        private void buttonN_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;            
            // определяем номер показываемой страницы
            nPageCurrent = Convert.ToInt32(btn.Text);

            // устанавливаем активную кнопку (выделяется цветом и рамкой)
            int n = btn.Name.Length; // длина имени кнопки
            string str = btn.Name.Substring(n - 1); // в конце номер кнопки
            nActiveBtn = Convert.ToInt32(str);
            // показываем все кнопки выделением активной
            ShowActiveBtn();
            // загружаем данные в другую страницу            
            ShowCurrentPage();
        }
        void SetPageBtn(int nPage)
        {
            for (int i = 0; i < 5; i++)
            {
                int ii = Convert.ToInt32(btnsList[i].Text);
                if (ii == nPage)
                    btnsList[i].BackColor = Color.LightBlue;
                else
                    btnsList[i].BackColor = Color.White;
            }
        }
        // задаем номер активной кнопки
        void ShowActiveBtn() // int nActiveBtn)
        {            
            for (int i=0; i<5; i++)
            {
                int ii = Convert.ToInt32(btnsList[i].Text);
                if (ii == nActiveBtn)
                    btnsList[i].BackColor = Color.LightBlue; 
                else
                    btnsList[i].BackColor = Color.White;                
            }
        }
        // изменяем номера на кнопках
        void ChangePageBtn(int d)
        {
            if(nPageAll < 5)
            {
                for (int i = nPageAll; i < 5; i++)
                {
                    btnsList[i].Enabled = false;
                }
            }

            for (int i = 0; i < 5; i++)
            {
                int n = Convert.ToInt32(btnsList[i].Text) + d;
                if (n < 1) return;
                btnsList[i].Text = n.ToString();                
            }
            nPageFirst = Convert.ToInt32(btnsList[0].Text);
        }
    }
}
