﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace LopushokApp
{
    class NewProduct
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public string ProductType { get; set; }
        public string ArticleNumber { get; set; }
        public string Description { get; set; }
        public Image picture { get; set; }
        public int ProductionPersonCount { get; set; }
        public int ProductionWorkshopNumber { get; set; }
        public double MinCostForAgent { get; set; }
        ///////////////////////////////////////
        // рассчетные показатели
        public string Materials { get; set; }
        public double MaterialCost { get; set; }
    }
}
